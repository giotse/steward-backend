package com.giotse.steward.event.dto;

import com.giotse.steward.person.dto.DataNewPersonDTO;

import java.util.List;

public record DataNewRegistrationDTO (
        Long idEvent,
        DataNewPersonDTO mainPerson,
        List<DataNewPersonDTO> guests
) {}
