package com.giotse.steward.event.service;

import com.giotse.steward.event.domain.Event;
import com.giotse.steward.event.dto.DataNewEventDTO;
import com.giotse.steward.event.repository.EventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EventService {
    private final EventRepository eventRepository;

    public Event inserirEvento(DataNewEventDTO newEventDTO) {
        return eventRepository.saveAndFlush(newEventDTO.getEvent());
    }
}
