package com.giotse.steward.person.service;

import com.giotse.steward.common.exception.BusinessException;
import com.giotse.steward.person.domain.Person;
import com.giotse.steward.person.dto.DataNewPersonDTO;
import com.giotse.steward.person.repository.PersonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;



@Service
@RequiredArgsConstructor
public class PersonService {
    private final PersonRepository personRepository;

    public void checkPersonExists(String fullName) {
        if (!personRepository.findByFullNameIgnoreCase(fullName).isEmpty()) {
            throw new BusinessException(STR."A inscrição de '\{fullName}' já foi realizada.");
        }
    }

    public Person inserir(DataNewPersonDTO newPersonDTO) {
        return personRepository.saveAndFlush(newPersonDTO.getPerson());
    }
}
