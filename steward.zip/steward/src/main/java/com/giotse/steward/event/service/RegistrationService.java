package com.giotse.steward.event.service;

import com.giotse.steward.common.exception.BusinessException;
import com.giotse.steward.event.domain.Event;
import com.giotse.steward.event.domain.EventRegistration;
import com.giotse.steward.event.dto.DataNewRegistrationDTO;
import com.giotse.steward.event.repository.EventRegistrationRepository;
import com.giotse.steward.event.repository.EventRepository;
import com.giotse.steward.person.domain.Person;
import com.giotse.steward.person.dto.DataNewPersonDTO;
import com.giotse.steward.person.service.PersonService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class RegistrationService {
    private final EventRepository eventRepository;
    private final PersonService personService;
    private final EventRegistrationRepository eventRegistrationRepository;

    @Transactional
    public void associatePersonsToEvent(DataNewRegistrationDTO dataNewRegistrationDTO) {
        var event = eventRepository.findById(dataNewRegistrationDTO.idEvent()).orElseThrow((() -> new BusinessException("Evento informado não exite.")));

        checkGuestsExists(dataNewRegistrationDTO);

        var mainPerson = personService.inserir(dataNewRegistrationDTO.mainPerson());
        // TODO: registrar main person no evento


        dataNewRegistrationDTO.guests().forEach(
                guest -> {
                    registrePersonInEvent(guest, mainPerson, event);
                }
        );

    }

    private void registrePersonInEvent(DataNewPersonDTO guest, Person mainPerson, Event event) {
        var person = personService.inserir(guest);
        person.setInvitedBy(mainPerson);
        var eventRegistration = new EventRegistration(null,  person, event, LocalDateTime.now());
        eventRegistrationRepository.saveAndFlush(eventRegistration);
    }

    private void checkGuestsExists(DataNewRegistrationDTO dataNewRegistrationDTO) {
        dataNewRegistrationDTO.guests().forEach(
                guest -> personService.checkPersonExists(guest.fullName())
        );
    }
}
