package com.giotse.steward.person.domain;

import com.giotse.steward.event.domain.EventRegistration;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Person {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;

    private Date birthday;

    private String email;

    @ManyToOne(cascade = CascadeType.ALL)
    private Person invitedBy;

    @OneToMany(mappedBy = "person")
    Set<EventRegistration> registrations;
}
