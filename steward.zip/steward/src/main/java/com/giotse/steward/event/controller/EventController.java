package com.giotse.steward.event.controller;

import com.giotse.steward.event.domain.Event;
import com.giotse.steward.event.dto.DataNewEventDTO;
import com.giotse.steward.event.dto.DataNewRegistrationDTO;
import com.giotse.steward.event.service.EventService;
import com.giotse.steward.event.service.RegistrationService;
import io.undertow.util.StatusCodes;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/events")
@RequiredArgsConstructor
public class EventController {
    private final EventService eventService;
    private final RegistrationService registrationService;

    @PostMapping
    ResponseEntity<Event> criarEvento(@RequestBody DataNewEventDTO newEventDTO) {
        return ResponseEntity.ok(eventService.inserirEvento(newEventDTO));
    }

    @PostMapping("inscricao")
    ResponseEntity<Void> inscreverPessoaEmEvento(@RequestBody DataNewRegistrationDTO newRegistrationDTO) {
        registrationService.associatePersonsToEvent(newRegistrationDTO);
        return ResponseEntity.status(StatusCodes.CREATED).build();
    }
}
