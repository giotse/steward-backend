package com.giotse.steward.event.dto;

import com.giotse.steward.event.domain.Event;

import java.time.LocalDateTime;
import java.util.Collections;

public record DataNewEventDTO (
        String name,
        LocalDateTime date,
        String location
) {
    public Event getEvent() {
        return new Event(null, name, date, location, Collections.emptySet());
    }
}
