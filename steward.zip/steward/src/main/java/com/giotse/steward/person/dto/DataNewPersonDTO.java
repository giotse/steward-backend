package com.giotse.steward.person.dto;

import com.giotse.steward.person.domain.Person;

import java.util.Date;

public record DataNewPersonDTO(
        String fullName,
        Date birthday,
        String email
) {
    public Person getPerson() {
        return new Person(null, fullName, birthday, email, null, null);
    }
}
