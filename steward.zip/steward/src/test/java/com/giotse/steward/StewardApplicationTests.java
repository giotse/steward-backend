package com.giotse.steward;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class StewardApplicationTests {

//	@Test
	void contextLoads() {
		assertNotNull("teste");
	}

}
